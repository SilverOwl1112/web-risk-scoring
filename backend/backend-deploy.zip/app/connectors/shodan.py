# Placeholder Shodan connector
def query_shodan(ip: str):
    return {"open_ports": [80, 443]}
